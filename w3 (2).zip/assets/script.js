$('.js-accordion').accordion({
    heightStyle: "content",
    collapsible: true
});

$('.tooltip-custom').tooltipster();

// $('.js-modal-custom').modal();
